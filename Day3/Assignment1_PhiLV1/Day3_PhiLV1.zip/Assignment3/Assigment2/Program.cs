﻿using Assignment2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment2
{
    class Program
    {
        static void Main(string[] args)
        {
            KiemTraDinhDang kiemTraDinhDang = new KiemTraDinhDang();


            int email, date, phone;
            while (true)
            {
                Console.Write("***********Menu***********");
                Console.Write("\n1 Check date");
                Console.Write("\n2 Check email");
                Console.Write("\n3 Check phone\n");
                int menu = Int16.Parse(Console.ReadLine());
                switch (menu)
                {

                    case 1:
                        {
                            String s = "";
                            Console.Write("\nNhap vao ngay thang nam\n");
                            s = Console.ReadLine();
                            bool check = true;
                            if (kiemTraDinhDang.checkDate(s) == "Good")
                            {
                                check = false;
                            }
                            Console.Write("\n" + kiemTraDinhDang.checkDate(s) + "\n");
                            while (check)
                            {
                                Console.Write("\nNhap vao ngay thang nam\n");
                                s = Console.ReadLine();
                                if (kiemTraDinhDang.checkDate(s) == "Good")
                                {
                                    check = false;
                                }
                                Console.Write("\n" + kiemTraDinhDang.checkDate(s) + "\n");
                            }
                        }
                        break;
                    case 2:
                        {
                            String s = "";
                            Console.Write("\nNhap vao email\n");
                            s = Console.ReadLine();
                            bool check = true;
                            if (kiemTraDinhDang.checkEmail(s) != "")
                            {
                                check = false;
                            }
                            Console.Write("\n" + kiemTraDinhDang.checkEmail(s) + "\n");
                            while (check)
                            {
                                Console.Write("\nNhap vao email\n");
                                s = Console.ReadLine();
                                if (kiemTraDinhDang.checkEmail(s) == "Good")
                                {
                                    check = false;
                                }
                                Console.Write("\n" + kiemTraDinhDang.checkDate(s) + "\n");
                            }
                        }
                        break;

                    case 3:
                        {
                            String s = "";
                            Console.Write("\nNhap vao phone\n");
                            s = Console.ReadLine();
                            bool check = true;
                            if (kiemTraDinhDang.checkPhone(s) == "Good")
                            {
                                check = false;
                            }
                            Console.Write("\n" + kiemTraDinhDang.checkDate(s) + "\n");
                            while (check)
                            {
                                Console.Write("\nNhap vao email\n");
                                s = Console.ReadLine();
                                if (kiemTraDinhDang.checkPhone(s) == "")
                                {
                                    check = false;
                                }
                                Console.Write("\n" + kiemTraDinhDang.checkDate(s) + "\n");
                            }
                        }
                        break;

                }
            }

        }
    }
}
