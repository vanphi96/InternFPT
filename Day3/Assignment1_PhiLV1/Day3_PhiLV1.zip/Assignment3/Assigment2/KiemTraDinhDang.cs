﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Assignment2
{
    class KiemTraDinhDang
    {
        public String checkPhone(String phone)
        {
            String thongBao = "Good";
            Regex regex1 = new Regex(".\\D");
            Regex regex2 = new Regex("[+84]|[0]d{9}");
            if (regex1.IsMatch(phone))
            {
                thongBao = "Phone number must is number";
            }
            else if (regex2.IsMatch(phone))
            {
                thongBao = "Phone number must be 10 digits";
            }
            return thongBao;
        }
        public String checkEmail(String email)
        {
            String thongBao = "Good";
            Regex regexEmail = new Regex(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$");
            if (!regexEmail.IsMatch(email))
            {
                thongBao = "Email must is correct format";
            }
            return thongBao;
        }
        public String checkDate(String date)
        {
            String thongBao = "Good";
            //Regex regex = new Regex(@"^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d$");
            //if (!regex.IsMatch(date))
            //{
            //    thongBao = "The date is not correct ";
            //}

            try
            {
                DateTime dateTime = DateTime.ParseExact(date, "dd/MM/yyyy", null);
              
            }
            catch(Exception e)
            {
                thongBao = "The date is not correct ";
            }
           
            return thongBao;
        }
    }
}
