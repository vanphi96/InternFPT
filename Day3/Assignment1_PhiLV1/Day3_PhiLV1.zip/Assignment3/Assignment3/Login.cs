﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Assignment3
{
    public class Account
    {
        public String UserName { get; set; }
        public String PassWord { get; set; }
        public String Name { get; set; }
        public String Phone { get; set; }
        public String Email { get; set; }
        public String Address { get; set; }
        public DateTime Birth { get; set; }
        public Account(String userName, String password, String name, String phone, String email, String address, DateTime birth)
        {
            UserName = userName;
            PassWord = password;
            Name = name;
            Phone = phone;
            Email = email;
            Address = address;
            Birth = birth;
        }

    }
    class Login
    {
       
        private List<Account> accounts = new List<Account>();

        public bool ChangePassWord(String password)
        {

            bool change = false;

            return change;
        }
        public bool checkPhone(String phone)
        {
           
            Regex regex2 = new Regex(@"[0]\d{9,10}");
            if (regex2.IsMatch(phone))
            {
                return true;
            }
            return false;
        }
        public bool checkEmail(String email)
        {
            Regex regexEmail = new Regex(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$");
            if (!regexEmail.IsMatch(email))
            {
                return false;
            }
            return true;
        }
        public DateTime checkDate(String date)
        {
            DateTime dateTime;
            DateTime.TryParse(date,out dateTime);
            return dateTime;
        }
        public bool checkPasswordUser(String user, String password)
        {
           
            if(password.ToLower().Contains(user.ToLower()))
            {
                Console.Write("\nPassword chua Username!");
                return false;
            }
            return true;

        }
        public bool checkPass(String password)
        {
            bool dk1 = false;
            bool dk2 = false;
            bool dk3 = false;
            bool dk4 = false;
            Regex regex1 = new Regex("[A-Z]");
            Regex regex2 = new Regex("[a-z]");
            Regex regex3 = new Regex("[0-9]");
            Regex regex4 = new Regex("[&!%@$#*^]");
            if (regex1.IsMatch(password))
            {
                dk1 = true;
            }
            if (regex2.IsMatch(password))
            {
                dk2 = true;
            }
            if (regex3.IsMatch(password))
            {
                dk3 = true;
            }
            if (regex4.IsMatch(password))
            {
                dk4 = true;
            }

            if (dk1 && dk2 && dk3 || dk1 && dk2 && dk4 || dk2 && dk3 && dk4 || dk1 && dk3 && dk4)
            {
                return true;
            }
            else
            {
                Console.Write("\nMat khau khong dung dinh dang!");
                return false;
            }
        }
        public int AddAcount(String userName, String passWord, String name,String phone, 
            String email, String address, DateTime birth)
        {
            if (checkPass(passWord))
            {
                accounts.Add(new Account(userName, passWord, name, phone, email, address, birth));
                return 1;
            }
            else
            {
                return -1;
            }

            
           
        }


        public void NhapAccount()
        {
            String account = "";
            String pass = "";
            String name = "";
            String phone = "";
            String email = "";
            String address = "";
            String birth = "";
            Console.Write("\nUserName: ");
            account = Console.ReadLine();

            do
            {

                Console.Write("\nPassword: ");
                pass = Console.ReadLine();
            }
            while (!checkPasswordUser(account, pass)||pass.Length<8||!checkPass(pass));

            Console.Write("\nName: ");
            name = Console.ReadLine();
            do
            {
                Console.Write("\nPhone: ");
                phone = Console.ReadLine();
            }
            while (!checkPhone(phone));

            do
            {
                Console.Write("\nEmail: ");
                email = Console.ReadLine();
            }
            while (!checkEmail(email));
            Console.Write("\nAddress: ");
            address = Console.ReadLine();

            do
            {
                Console.Write("\nDate of Birht: ");
                birth = Console.ReadLine();
            }
            while (checkDate(birth)==null);

            if (checkPass(pass))
            {
                AddAcount(account, pass, name, phone, email, address, checkDate(birth));
            }

        }
        public int ChangePassWord(String oldPass, String newPass, ref Account account)
        {
            if (oldPass.Equals(account.PassWord))
            {
                if (checkPass(newPass) && checkPasswordUser(account.UserName, oldPass))
                {
                    account.PassWord = newPass;
                    return 1;
                }
                return 0;
            }
            else
            {
                Console.Write("\nMat khau cu khong chinh xac khong dung!");
                return -1;
                    
            }
        }
        public Account Sign(String user, String pass)
        {
            foreach(Account ac in accounts)
            {
                if (user.Equals(ac.UserName) && pass.Equals(ac.PassWord))
                {
                    return ac;
                }
            }
            return null;
        }
        public void RunLogin()
        {
            String user = "";
            String pass = "";
            Console.Write("\nNhap User: ");
            user = Console.ReadLine();
            Console.Write("\nNhap Password: ");
            pass = Console.ReadLine();
            Account account = Sign(user, pass);
            if (account != null)
            {
                Console.Write("------------ Wellcome -----------\n");
                Console.Write("\nHi " + account.Name + ", do you want change password now? Y/N:");
                String select = "";
                String passReNew =Console.ReadLine();
                select = select.ToLower();
                String passNew =  "";
                String oldPass = "";
                if (select == "y")
                {
                    
                    do
                    {
                        Console.Write("\n Nhap 'N' de thoat hoac Old Password de tiep tuc:");
                        oldPass = Console.ReadLine();
                        if (oldPass.ToLower().Equals("n"))
                        {
                            return;
                        }
                    }
                    while (!account.PassWord.Equals(oldPass));

                    Console.Write("\nNew password:");
                    passNew = Console.ReadLine();
                    Console.Write("\nRenew password:");
                    passReNew = Console.ReadLine();
                    if (!passNew.Equals(passReNew))
                    {
                        Console.Write("\nMat khau nhap lai khong trung khop!");
                        return;
                    }

                    else
                    {
                        if (passNew.Length < 8)
                        {
                            Console.Write("\nMat khau nho hon 8 ki tu!");
                            return;
                        }
                        if (!checkPasswordUser(passNew, account.UserName))
                        {
                            Console.Write("\nMat khau khong duoc chua username!");
                            return;
                        }
                        else if (!checkPass(passNew)){
                            Console.Write("\nMat khau khong dat yeu cau ve bao mat!");
                            return;
                        }
                        accounts.Remove(account);
                        account.PassWord = passNew;
                        accounts.Add(account);
                        Console.Write("\nDoi mat khau thanh cong!");
                        return;
                    }
                  
                }
            }
        }
        public void Menu()
        {
            while (true)
            {
                Console.Write("\n============ Login Program =========");
                Console.Write("\n1. Add Account");
                Console.Write("\n2. Login");
                Console.Write("\n3. Exit");
                Console.Write("\nPlease choice one option:");
                int select = Int16.Parse(Console.ReadLine());
                switch(select)
                {
                    case 1:
                        {
                            NhapAccount();
                        }
                        break;

                    case 2:
                        {
                            RunLogin();
                        }
                            
                        break;

                    case 3:
                        return;
                }
            }
            
           
        }
    }
}
