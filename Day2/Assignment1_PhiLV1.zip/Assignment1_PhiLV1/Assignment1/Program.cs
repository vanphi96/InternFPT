﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Bai1 b1 = new Bai1();
            //b1.Run();

            //Bai2 b2 = new Bai2();
            //b2.Run();

            //Bai3 b3 = new Bai3();
            //b3.Run();

            //Bai4 b4 = new Bai4();
            //b4.Run();

            //Bai5 b5 = new Bai5();
            //b5.Run();

            //Bai6 b6 = new Bai6();
            //b6.Run();

            //Bai7 b7 = new Bai7();
            //b7.Run();

            //Bai8 b8 = new Bai8();
            //b8.Run();

            //Bai9 b9 = new Bai9();
            //b9.Run();

            Bai10 b10 = new Bai10();
            b10.Run();
        }
    }
}
