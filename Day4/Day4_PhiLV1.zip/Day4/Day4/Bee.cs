﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    public abstract class Bee
    {
        public String Type;
        public bool Status { get; set; } = true;
        public int Health { get; set; } = 100;
        public abstract void CheckHealth();
        public abstract void Combat();
    }
}
