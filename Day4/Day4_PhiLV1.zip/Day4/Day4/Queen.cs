﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Queen : Bee
    {
        public Queen()
        {
            Type = "Queen";
        }
        public override void CheckHealth()
        {
            if (Health < 20)
            {
                Status = false;
            }
        }

        public override void Combat()
        {
            Random random = new Random();
            Health= Health- random.Next(0, 80);
            CheckHealth();
        }
    }
}
