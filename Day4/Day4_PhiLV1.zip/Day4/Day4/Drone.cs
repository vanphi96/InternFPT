﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Drone : Bee
    {

        public Drone()
        {
            Type = "Drone";
        }
        public override void CheckHealth()
        {
           
            if (Health < 50)
            {
                Status = false;
            }
        }

        public override void Combat()
        {
            Random random = new Random();
            Health = Health - random.Next(0, 80);
            CheckHealth();
        }
    }
}
