﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Program
    {
        public List<Bee> GetBees()
        {
            int amountDrone = 0;
            int amountQueen = 0;
            int amountWorker = 0;
            Random random = new Random();
            amountDrone = random.Next(1, 8);
            amountQueen = random.Next(1, 10 - amountDrone - 1);
            amountWorker = 10 - amountDrone - amountQueen;
            List<Bee> bees = new List<Bee>();
            for (int i = 0; i < amountDrone; i++)
            {
                bees.Add(new Drone());
            }
            for (int i = 0; i < amountWorker; i++)
            {
                bees.Add(new Worker());
            }
            for (int i = 0; i < amountQueen; i++)
            {
                bees.Add(new Queen());
            }

            return bees;
        }
        public void Out(List<Bee> bees)
        {
            int drone = 0;
            int queen = 0;
            int worker = 0;
            for (int i = 0; i < bees.Count; i++)
            {
                if (bees[i].Type == "Drone")
                {
                    drone++;
                }
                if (bees[i].Type == "Queen")
                {
                    queen++;
                }
                if (bees[i].Type == "Worker")
                {
                    worker++;
                }

            }
            Console.Write("\nDrone: {0},    Queen: {1},    Worker: {2}", drone, queen, worker);
        }
        public bool OutLive(List<Bee> bees)
        {
            int dem = 0;
            for (int i = 0; i < bees.Count; i++)
            {
                if (bees[i].Status) { dem++; }
            }
            if (dem != 0)
            {
                Console.Write("\nSo ong con song: {0}", dem);
                return false;
            }
            return true;

        }
        static void Main(string[] args)
        {
            List<Bee> bees = new List<Bee>();
            Program program = new Program();
            bool live = false;
            while (true)
            {
                Console.Write("\n1. Tao");
                Console.Write("\n2. Danh");
                Console.Write("\n3. Exit\n");
                int selected = Int16.Parse(Console.ReadLine());
                switch (selected)
                {
                    case 1:
                        {
                            live = true;
                            bees = program.GetBees();
                            program.Out(bees);
                        }
                        break;
                    case 2:
                        {
                            if (bees.Count == 0)
                            {
                                Console.Write("\nKhong co ong trong list");
                            }
                            for (int i = 0; i < bees.Count; i++)
                            {
                                bees[i].Combat();
                                if (bees[i].Status)
                                {
                                    live = true;
                                }
                            }
                            if (program.OutLive(bees))
                            {
                                Console.Write("\nWin!");
                                live = true;
                                bees = new List<Bee>();
                            }
                        }
                        break;
                    case 3:
                        return;
                        break;
                }

            }
        }
    }
}
