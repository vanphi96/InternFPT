﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Worker : Bee
    {
        public Worker()
        {
            Type = "Worker";
        }
        public override void CheckHealth()
        {
            if (Health < 70)
            {
                Status = false;
            }
        }

        public override void Combat()
        {
            Random random = new Random();
            Health = Health - random.Next(0, 80);
            CheckHealth();
        }
    }
}
