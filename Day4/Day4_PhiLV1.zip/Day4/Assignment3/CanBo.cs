﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    abstract class CanBo
    {
        public string HoTen { get; set; }
        public double HeSoLuong { get; set; }
        public double PhuCap { get; set; }
        public short SoDonViLamViec { get; set; }
        public string Type { get; set; }
        public string NoiLamViec { get; set; }
        public CanBo(string hoTen, double heSoLuong, double phuCap, 
            short soDonViLamViec, string type, string noiLamViec)
        {
            HoTen = hoTen;
            HeSoLuong = heSoLuong;
            PhuCap = phuCap;
            SoDonViLamViec = soDonViLamViec;
            Type = type;
            NoiLamViec = noiLamViec;
        }
        public abstract double Luong();
        public abstract void Out();
    }
}
