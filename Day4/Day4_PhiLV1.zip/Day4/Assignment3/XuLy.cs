﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class XuLy
    {
        
        public static void Menu()
        {
            List<CanBo> canBos = new List<CanBo>();
            while (true)
            {
                
                Console.Write("\n============QLCB=============");
                Console.Write("\n1. Them can bo");
                Console.Write("\n2. Tim kiem nhan vien theo ten va phong ban");
                Console.Write("\n3. Hien danh sach can bo da sap xep");
                Console.Write("\n4. Thoat\n");
                short select = Int16.Parse(Console.ReadLine());
                switch (select)
                {
                    case 1:
                        canBos = NhapCanBo(canBos);
                        break;
                    case 2:
                        {
                            string ten = "";
                            CanBo canBo = TimCanBo(canBos,ref ten);
                            if (canBo == null && ten != "")
                            {
                                Console.Write("\nKhong tim thay can bo");
                            }
                            else if (canBo != null)
                            {
                                canBo.Out();
                            }
                        }
                       
                        break;
                    case 3:
                        {
                            Sort(canBos);
                            for (int i = 0; i < canBos.Count; i++)
                            {
                                canBos[i].Out();
                            }
                        }
                        break;
                    case 4:
                        return;
                }
            }
            
        }
        public static List<String> CatChuoi(string hoten)
        {

            string s = hoten;
            List<String> listTu = new List<String>();
            while (s.IndexOf("  ") >= 0)
            {
                s = s.Remove(s.IndexOf("  "), 1);
            }
            s = s.Trim();
            string[] tu = s.Split(' ');
            for (int i = 0; i < tu.Length; i++)
            {
                tu[i] = tu[i].ToLower();
                List<char> kytu = new List<char>();
                kytu.AddRange(tu[i].ToCharArray());
                for (int j = 0; j < kytu.Count; j++)
                {
                    if (kytu[j] == ' ')
                    {
                        kytu.RemoveAt(j);
                    }
                }
                String gheptu = "";
                for (int j = 0; j < kytu.Count; j++)
                {
                    if (j == 0)
                    {
                        gheptu = kytu[j].ToString().ToUpper();
                    }
                    else
                    {
                        gheptu += kytu[j].ToString();

                    }
                }
                listTu.Add(gheptu);

            }
            return listTu;

        }
        public static List<CanBo> Sort(List<CanBo> canBos)
        {
            for(int i=0; i<canBos.Count-1; i++)
            {
                for(int j=i+1; j<=canBos.Count-1; j++)
                {
                    if (canBos[i].Luong() > canBos[j].Luong())
                    {
                        CanBo canBo = canBos[i];
                        canBos[i] = canBos[j];
                        canBos[j] = canBo;
                    }
                    if(canBos[i].Luong() == canBos[j].Luong())
                    {
                        char[] ten1 = CatChuoi(canBos[i].HoTen)[CatChuoi(canBos[i].HoTen).Count - 1].ToCharArray();
                        char[] ten2 = CatChuoi(canBos[j].HoTen)[CatChuoi(canBos[j].HoTen).Count - 1].ToCharArray();
                        if (ten1[0] > ten2[0])
                        {
                            CanBo canBo = canBos[i];
                            canBos[i] = canBos[j];
                            canBos[j] = canBo;
                        }
                    }
                }
            }
            return canBos;
        }
        public static List<CanBo> NhapCanBo(List<CanBo> canBos)
        {
            short select = 0;
            do
            {
                Console.Write("\n ====Loai can bo====");
                Console.Write("\n1. Giang vien");
                Console.Write("\n2. Nhan vien");
                Console.Write("\n3. Thoat");
                Console.Write("\nLua chon:  \n");
                select = Int16.Parse(Console.ReadLine());
            }
            while (select != 1 && select != 2 && select != 3);
            if (select != 3)
            {
                string hoTen = "";
                string noiLamViec = "";
                TrinhDo trinhDo = TrinhDo.none;
                double phuCap = 0;
                ChucVu chucVu= ChucVu.none;
                short soDonViLamViec = 0;
                double heSoLuong = 0;
                Console.Write("\nHo ten:   \n");
                hoTen = Console.ReadLine();
                if (select == 1)
                {
                    short choose = 0;
                    Console.Write("\nKhoa giang day:\n");
                    noiLamViec = Console.ReadLine();
                    do
                    {
                        Console.Write("\nTrinh do:");
                        Console.Write("\n1. Cu nhan ");
                        Console.Write("\n2. Thac si ");
                        Console.Write("\n3. Tien si");
                        Console.Write("\n4. Thoat");
                        Console.Write("\n Lua chon: ");
                        choose = Int16.Parse(Console.ReadLine());
                    }
                    while (choose != 1 && choose != 2 && choose != 3);
                    switch (choose)
                    {
                        case 1:
                            {
                                trinhDo = TrinhDo.CuNhan;
                                phuCap = 300;
                            }

                            break;
                        case 2:
                            {
                                trinhDo = TrinhDo.ThacSi;
                                phuCap = 500;
                            }

                            break;
                        case 3:
                            {
                                trinhDo = TrinhDo.TienSi;
                                phuCap = 1000;
                            }

                            break;
                        case 4:
                            return canBos;
                    }
                    do
                    {
                        Console.Write("\nSo tiet day trong thang:\n");
                        soDonViLamViec = Int16.Parse(Console.ReadLine());
                    }

                    while (soDonViLamViec < 0);

                }



                if (select == 2)
                {
                    short choose = 0;
                    Console.Write("\nPhong ban:\n");
                    noiLamViec = Console.ReadLine();
                    do
                    {
                        Console.Write("\nChuc vu:");
                        Console.Write("\n1. Truong phong ");
                        Console.Write("\n2. Pho phong ");
                        Console.Write("\n3. Nhan vien");
                        Console.Write("\n4. Thoat");
                        Console.Write("\n Lua chon: ");
                        choose = Int16.Parse(Console.ReadLine());
                    }
                    while (choose != 1 && choose != 2 && choose != 3);
                    switch (choose)
                    {
                        case 1:
                            {
                                chucVu = ChucVu.Truongphong;
                                phuCap = 2000;
                            }

                            break;
                        case 2:
                            {
                                chucVu = ChucVu.Phophong;
                                phuCap = 1000;
                            }

                            break;
                        case 3:
                            {
                                chucVu = ChucVu.Nhanvien;
                                phuCap = 500;
                            }

                            break;
                        case 4:
                            return canBos;
                    }
                    do
                    {
                        Console.Write("\nSo ngay cong:\n");
                        soDonViLamViec = Int16.Parse(Console.ReadLine());
                    }
                    while (soDonViLamViec < 0);

                }

                do
                {
                    Console.Write("\nHe so luong:\n");
                    heSoLuong = double.Parse(Console.ReadLine());
                }
                while (heSoLuong < 0);

                if (select == 1)
                {
                    canBos.Add(new GiangVien(noiLamViec, trinhDo, soDonViLamViec, hoTen, heSoLuong, phuCap, "GiangVien"));
                    
                }
                else
                {
                    canBos.Add(new NhanVien(noiLamViec, chucVu, soDonViLamViec, hoTen, heSoLuong, phuCap, "NhanVien"));
                }
                canBos[canBos.Count - 1].Out();
            }


            return canBos;

        }
        public static CanBo TimCanBo(List<CanBo> canBos, ref string ten)
        {
            short select=0;
            ten = "";
            string noiLamviec = "";
            do
            {
                Console.Write("\n=========Tim kiem============");
                Console.Write("\n1. Giang vien");
                Console.Write("\n2. Nhan vien");
                Console.Write("\n3. Thoat");
                Console.Write("\nLua chon: \n");
                select = Int16.Parse(Console.ReadLine());
            }
            while (select != 1 && select != 2 && select != 3) ;
            if (select != 3)
            {
                if (select == 1)
                {
                    Console.Write("\nTen giang vien\n");
                    ten = Console.ReadLine();
                    Console.Write("\nkhoa\n");
                    noiLamviec = Console.ReadLine();
                    for(int i=0; i<canBos.Count; i++)
                    {
                        if (canBos[i].Type == "GiangVien"&& canBos[i].HoTen.Equals(ten)&&canBos[i].NoiLamViec.Equals(noiLamviec))
                        {
                            return canBos[i];
                        }
                    }
                }
                if (select == 2)
                {
                    Console.Write("\nTen nhan vien\n");
                    ten = Console.ReadLine();
                    Console.Write("\nPhong ban\n");
                    noiLamviec = Console.ReadLine();
                    for (int i = 0; i < canBos.Count; i++)
                    {
                        if (canBos[i].Type == "NhanVien" && canBos[i].HoTen.Equals(ten) && canBos[i].NoiLamViec.Equals(noiLamviec))
                        {
                            return canBos[i];
                        }
                    }
                }
            }
            else
            {
                return null;
            }
          

            return null;
        }

    }
}
