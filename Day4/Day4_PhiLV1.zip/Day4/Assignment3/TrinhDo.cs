﻿
namespace Assignment3
{
    public enum TrinhDo
    {
        CuNhan,
        ThacSi,
        TienSi,
        none
    }
}
