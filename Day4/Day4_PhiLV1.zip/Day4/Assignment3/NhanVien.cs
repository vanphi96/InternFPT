﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class NhanVien:CanBo
    {
        
        
        public ChucVu ChucVu { get; set; }
        public NhanVien(string phongBan, ChucVu chucVu,short soNgayLamViec, string hotTen, double heSoLuong, double phuCap, string type)
            :base(hotTen, heSoLuong, phuCap, soNgayLamViec, type, phongBan)
        {
            ChucVu = chucVu;
        }

        public override double Luong()
        {
            return HeSoLuong * 730 + PhuCap + SoDonViLamViec * 30;
        }

        public override void Out()
        {
            Console.Write("\n\n==========Thong tin cao bo============");
            Console.Write("\nLoai: {0}", Type);
            Console.Write("\nHo ten: {0}",HoTen);
            Console.Write("\nPhong ban: {0}",NoiLamViec);
            Console.Write("\nChuc vu: {0}",ChucVu.ToString());
            Console.Write("\nSo ngay cong: {0}", SoDonViLamViec);
            Console.Write("\nHe so luong: {0}", HeSoLuong);
            Console.Write("\nPhu cap: {0}",PhuCap);
            Console.Write("\nLuong: {0}", Luong());
        }
    }
}
