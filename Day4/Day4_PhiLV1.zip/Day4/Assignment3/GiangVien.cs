﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class GiangVien:CanBo
    {
        
        public TrinhDo TrinhDo { get; set; }
        public GiangVien(string khoa, TrinhDo trinhDo, short soTietDay, string hotTen, double heSoLuong, double phuCap, string type)
            :base(hotTen,heSoLuong,phuCap, soTietDay, type, khoa)
        {
            TrinhDo = trinhDo;
        }

        public override double Luong()
        {
            return HeSoLuong * 730 + PhuCap + SoDonViLamViec * 30;
        }

        public override void Out()
        {
            Console.Write("\n\n==========Thong tin cao bo============");
            Console.Write("\nLoai: {0}", Type);
            Console.Write("\nHo ten: {0}", HoTen);
            Console.Write("\nKhoa: {0}", NoiLamViec);
            Console.Write("\nTrinh do: {0}", TrinhDo.ToString());
            Console.Write("\nSo ngay cong: {0}", SoDonViLamViec);
            Console.Write("\nHe so luong: {0}", HeSoLuong);
            Console.Write("\nPhu cap: {0}", PhuCap);
            Console.Write("\nLuong: {0}", Luong());
        }
    }
}
