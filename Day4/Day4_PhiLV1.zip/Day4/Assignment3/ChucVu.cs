﻿
namespace Assignment3
{
    public enum ChucVu
    {
        Truongphong,
        Phophong,
        Nhanvien,
        none
    }
}
